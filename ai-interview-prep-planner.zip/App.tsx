import React, { useState, useCallback } from 'react';
import { PrepPlanForm } from './components/PrepPlanForm';
import { PlanDisplay } from './components/PlanDisplay';
import { LoadingSpinner } from './components/LoadingSpinner';
import { ErrorMessage } from './components/ErrorMessage';
import { generatePrepPlan } from './services/geminiService';
import type { FormData, PrepPlan } from './types';
import { Header } from './components/Header';
import { Welcome } from './components/Welcome';

const App: React.FC = () => {
  const [plan, setPlan] = useState<PrepPlan | null>(null);
  const [currentFormData, setCurrentFormData] = useState<FormData | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [currentDay, setCurrentDay] = useState<number>(0);

  const handleReset = useCallback(() => {
    setPlan(null);
    setError(null);
    setCurrentDay(0);
    setCurrentFormData(null);
  }, []);

  const handleGeneratePlan = useCallback(async (formData: FormData) => {
    setIsLoading(true);
    setError(null);
    setPlan(null);
    setCurrentDay(0);
    setCurrentFormData(null);

    try {
      const generatedPlan = await generatePrepPlan(formData);
      setPlan(generatedPlan);
      setCurrentFormData(formData); // Store the form data on success
    } catch (err) {
      console.error(err);
      setError(err instanceof Error ? err.message : 'An unexpected error occurred. Please try again.');
    } finally {
      setIsLoading(false);
    }
  }, []);

  return (
    <div className="min-h-screen bg-slate-900 text-slate-200 flex flex-col items-center p-4 sm:p-6 lg:p-8">
      <div className="w-full max-w-7xl mx-auto">
        <Header />
        <main className="mt-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
            <div className="lg:col-span-4">
               {/* Show form only if there is no plan */}
              {!plan && <PrepPlanForm onGenerate={handleGeneratePlan} isLoading={isLoading} />}
               {/* Show a placeholder or different content if a plan is active */}
               {plan && !isLoading && !error && (
                 <div className="bg-slate-800/50 p-6 rounded-xl border border-slate-700/50 sticky top-8 text-center">
                    <h2 className="text-xl font-bold text-white mb-4">Your Plan is Ready!</h2>
                    <p className="text-slate-400 mb-4">Follow the daily steps on the right to prepare for your interview.</p>
                    <button
                        onClick={handleReset}
                        className="w-full inline-flex justify-center items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition-colors"
                    >
                        Create a New Plan
                    </button>
                 </div>
               )}
            </div>
            <div className="lg:col-span-8">
              <div className="bg-slate-800/50 rounded-xl p-6 min-h-[400px] border border-slate-700/50 flex flex-col justify-center">
                {isLoading && <LoadingSpinner />}
                {error && <ErrorMessage message={error} />}
                {plan && currentFormData && !isLoading && !error && (
                  <PlanDisplay
                    planData={plan}
                    formData={currentFormData}
                    currentDay={currentDay}
                    setCurrentDay={setCurrentDay}
                    onReset={handleReset}
                  />
                )}
                {!isLoading && !error && !plan && <Welcome />}
              </div>
            </div>
          </div>
        </main>
      </div>
       <footer className="w-full max-w-7xl mx-auto text-center py-6 mt-8 text-slate-500 text-sm">
        <p>Powered by AI. Your personalized career coach.</p>
      </footer>
    </div>
  );
};

export default App;