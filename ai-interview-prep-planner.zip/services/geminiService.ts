import { GoogleGenAI, Type } from "@google/genai";
import type { FormData, PrepPlan, MockInterview } from '../types';

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  throw new Error("API_KEY environment variable is not set.");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });

const planSchema = {
  type: Type.OBJECT,
  properties: {
    summary: {
      type: Type.STRING,
      description: "A short, encouraging summary paragraph explaining the goal of this personalized plan.",
    },
    plan: {
      type: Type.ARRAY,
      description: "The detailed daily plan.",
      items: {
        type: Type.OBJECT,
        properties: {
          day: {
            type: Type.INTEGER,
            description: "The day number (e.g., 1, 2, 3...).",
          },
          title: {
            type: Type.STRING,
            description: "A unique, engaging banner title for the day, including an emoji. Example: 'Day 1: 🔧 Build the Foundation'",
          },
          topics: {
            type: Type.STRING,
            description: "Technical topics to cover for the day. Be specific and relevant to the job role and company type.",
          },
          activities: {
            type: Type.STRING,
            description: "Specific activities, exercises, or online resources (like LeetCode, specific articles, or project ideas) to practice the topics.",
          },
          softSkills: {
            type: Type.STRING,
            description: "Soft skills or HR interview preparation topics, like behavioral questions (STAR method), resume review, or company research.",
          },
          notes: {
            type: Type.STRING,
            description: "A helpful tip or note for the day to keep the user motivated and focused.",
          },
        },
        required: ["day", "title", "topics", "activities", "softSkills", "notes"],
      },
    },
  },
  required: ["summary", "plan"],
};

const mockInterviewSchema = {
  type: Type.OBJECT,
  properties: {
    technicalQuestions: {
      type: Type.ARRAY,
      description: "A list of 3-5 technical interview questions relevant to the job role and company type.",
      items: {
        type: Type.OBJECT,
        properties: {
          question: { type: Type.STRING },
        },
        required: ["question"],
      },
    },
    behavioralQuestions: {
      type: Type.ARRAY,
      description: "A list of 2-4 behavioral/HR questions tailored to the company type.",
      items: {
        type: Type.OBJECT,
        properties: {
          question: { type: Type.STRING },
        },
        required: ["question"],
      },
    },
    resources: {
      type: Type.ARRAY,
      description: "A list of 2-3 specific, high-quality online resources for final practice.",
      items: {
        type: Type.OBJECT,
        properties: {
          name: { type: Type.STRING, description: "The name of the resource (e.g., LeetCode, Frontend Mentor)." },
          url: { type: Type.STRING, description: "The direct URL to the resource." },
          description: { type: Type.STRING, description: "A brief, one-sentence description of why this resource is useful for this candidate." },
        },
        required: ["name", "url", "description"],
      },
    },
    mcqs: {
      type: Type.ARRAY,
      description: "A list of 5-10 multiple-choice questions (MCQs) to test foundational knowledge.",
      items: {
        type: Type.OBJECT,
        properties: {
          question: { type: Type.STRING, description: "The question text." },
          options: {
            type: Type.ARRAY,
            description: "An array of exactly 4 string options.",
            items: { type: Type.STRING }
          },
          correctAnswer: {
            type: Type.STRING,
            description: "The correct answer, which must exactly match one of the strings in the 'options' array."
          }
        },
        required: ["question", "options", "correctAnswer"]
      }
    }
  },
  required: ["technicalQuestions", "behavioralQuestions", "resources", "mcqs"],
};

export const generatePrepPlan = async (formData: FormData): Promise<PrepPlan> => {
  const { jobRole, experienceLevel, timePerDay, focusSkills, interviewDays, companyType } = formData;
  const numDays = parseInt(interviewDays, 10);

  if (isNaN(numDays) || numDays < 1 || numDays > 30) {
      throw new Error("Please enter a valid number of days (1-30).");
  }

  const prompt = `
    Act as an expert Career Coach and AI Job Interview Mentor with deep experience in hiring for technical roles. Your audience is freshers and early-career job seekers (0-2 years experience).

    Your goal is to generate a personalized, structured, and encouraging interview preparation plan to help a candidate succeed. The plan should balance technical skills, practical activities, and soft/HR skills preparation to build confidence and reduce anxiety.

    Here are the candidate's details:
    - Job Role: ${jobRole}
    - Experience Level: ${experienceLevel}
    - Company Type: ${companyType}
    - Time Available Per Day: ${timePerDay}
    - Days Until Interview: ${interviewDays}
    - Specific Skills to Improve: ${focusSkills || "General preparation"}

    Please create a ${interviewDays}-day plan based on these details. The plan MUST have exactly ${interviewDays} days. For each day, create a unique, engaging banner title that includes a relevant emoji (e.g., "Day 1: 🔧 Build the Foundation: HTML/CSS Mastery").
    Ensure the content is tailored for a fresher/early-career level and the specified company type.
    - For Startups, emphasize practical skills, quick problem-solving, and culture-fit questions.
    - For MNCs/Product-Based companies, focus more on data structures, algorithms, system design fundamentals, and structured behavioral answers (STAR method).
    - For Service-Based companies, include aptitude, logical reasoning, and communication skills.

    Generate a response in JSON format that adheres to the provided schema. The activities and resources should be practical and actionable. The tone should be motivational and supportive.
  `;
  
  try {
    const response = await ai.models.generateContent({
      // FIX: Changed model to gemini-2.5-pro for better handling of complex task.
      model: "gemini-2.5-pro",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: planSchema,
        temperature: 0.7,
      },
    });

    const jsonText = response.text.trim();
    const parsedPlan = JSON.parse(jsonText) as PrepPlan;
    
    // Validate that the plan has the correct number of days.
    if (!parsedPlan.plan || parsedPlan.plan.length !== numDays) {
        console.warn(`Generated plan has ${parsedPlan.plan?.length} days, but expected ${numDays}.`);
        if (!parsedPlan.plan) throw new Error("The generated plan is incomplete. Please try again.");
    }

    return parsedPlan;
  } catch (error) {
    console.error("Error generating plan from Gemini API:", error);
    throw new Error("Failed to generate the interview plan. The AI model may be temporarily unavailable.");
  }
};

export const generateMockInterview = async (jobRole: string, companyType: string): Promise<MockInterview> => {
  const prompt = `
    Act as an expert Career Coach creating a final mock interview test for an early-career candidate.

    Candidate Details:
    - Job Role: ${jobRole}
    - Company Type: ${companyType}

    Your Task:
    Generate a concise mock interview with questions and resources tailored to the candidate's details.

    Instructions:
    1.  **Technical Questions:** Create 3-5 questions.
        - For Web Dev roles, include coding scenarios (e.g., "Explain JavaScript event delegation") or conceptual questions.
        - For Data Science, include questions about algorithms, statistics, or Python libraries.
        - For Product Manager, focus on case studies or product design questions.
    2.  **Behavioral/HR Questions:** Create 2-4 questions.
        - For Startups, ask about adaptability, initiative, and handling ambiguity (e.g., "Describe a time you had to learn a new technology quickly.").
        - For MNCs/Product-Based, ask about teamwork, handling conflict, and structured problem-solving (e.g., "Tell me about a complex project you worked on and your role in it.").
    3.  **Suggested Resources:** Provide 2-3 highly relevant links for last-minute practice. Ensure URLs are valid.
    4.  **Multiple Choice Questions (MCQs):** Generate 5 technical MCQs to test fundamental knowledge. Each MCQ must have exactly 4 options and one correct answer. The \`correctAnswer\` field must be an exact match to one of the strings in the \`options\` array.

    Generate a response in JSON format that adheres to the provided schema. The tone should be like a final checkpoint before the real interview.
  `;

  try {
    const response = await ai.models.generateContent({
      // FIX: Changed model to gemini-2.5-pro for better handling of complex task.
      model: "gemini-2.5-pro",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: mockInterviewSchema,
        temperature: 0.8,
      },
    });

    const jsonText = response.text.trim();
    return JSON.parse(jsonText) as MockInterview;
  } catch (error) {
    console.error("Error generating mock interview from Gemini API:", error);
    throw new Error("Failed to generate the mock interview. The AI model may be temporarily unavailable.");
  }
};