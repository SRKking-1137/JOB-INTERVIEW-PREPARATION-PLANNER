export interface FormData {
  jobRole: string;
  experienceLevel: string;
  timePerDay: string;
  focusSkills: string;
  interviewDays: string;
  companyType: string;
}

export interface PlanDay {
  day: number;
  title: string;
  topics: string;
  activities: string;
  softSkills: string;
  notes: string;
}

export interface PrepPlan {
  summary: string;
  plan: PlanDay[];
}

export interface MockQuestion {
  question: string;
}

export interface MockResource {
  name: string;
  url: string;
  description: string;
}

export interface MCQ {
  question: string;
  options: string[];
  correctAnswer: string;
}

export interface MockInterview {
  technicalQuestions: MockQuestion[];
  behavioralQuestions: MockQuestion[];
  resources: MockResource[];
  mcqs: MCQ[];
}