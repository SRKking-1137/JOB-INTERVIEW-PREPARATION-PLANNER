import React from 'react';
import { BriefcaseIcon } from './IconComponents';

export const Header: React.FC = () => {
  return (
    <header className="text-center">
      <div className="flex justify-center items-center gap-4">
        <BriefcaseIcon className="w-10 h-10 text-indigo-400" />
        <h1 className="text-4xl font-bold tracking-tight text-white sm:text-5xl">
          AI Interview Prep Planner
        </h1>
      </div>
      <p className="mt-4 text-lg leading-8 text-slate-400 max-w-3xl mx-auto">
        Your personalized roadmap to interview success. Fill out the form to get a custom plan from your AI career coach.
      </p>
    </header>
  );
};