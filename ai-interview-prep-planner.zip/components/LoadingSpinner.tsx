
import React from 'react';

export const LoadingSpinner: React.FC = () => {
  return (
    <div className="flex flex-col items-center justify-center h-full text-center">
      <div className="w-12 h-12 rounded-full animate-spin border-4 border-solid border-indigo-500 border-t-transparent"></div>
      <p className="mt-4 text-slate-300 font-medium">Crafting your personalized plan...</p>
      <p className="text-sm text-slate-400">This may take a moment.</p>
    </div>
  );
};
