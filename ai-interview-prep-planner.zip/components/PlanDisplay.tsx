import React, { useState, useEffect, useCallback } from 'react';
import type { PrepPlan, FormData, MockInterview } from '../types';
import { DAY_IMAGES } from '../constants';
import { generateMockInterview } from '../services/geminiService';
import { LoadingSpinner } from './LoadingSpinner';
import { ErrorMessage } from './ErrorMessage';
import { 
  TargetIcon, ActivityIcon, UsersIcon, LightbulbIcon, 
  ArrowLeftIcon, ArrowRightIcon, RefreshIcon, LinkIcon, ClipboardCheckIcon,
  QuestionMarkCircleIcon, CheckCircleIcon, XCircleIcon,
} from './IconComponents';

interface PlanDisplayProps {
  planData: PrepPlan;
  formData: FormData;
  currentDay: number;
  setCurrentDay: (day: number) => void;
  onReset: () => void;
}

const ProgressBar: React.FC<{ current: number, total: number }> = ({ current, total }) => {
  const percentage = ((current + 1) / total) * 100;
  return (
    <div className='my-4'>
       <div className="flex justify-between mb-1">
        <span className="text-base font-medium text-slate-300">Day {current + 1} of {total}</span>
        <span className="text-sm font-medium text-slate-300">{Math.round(percentage)}%</span>
      </div>
      <div className="w-full bg-slate-700 rounded-full h-2.5">
        <div className="bg-indigo-500 h-2.5 rounded-full transition-all duration-500" style={{ width: `${percentage}%` }}></div>
      </div>
    </div>
  );
};

const colorClasses = {
  sky: { bg: 'bg-sky-500/10', text: 'text-sky-400' },
  emerald: { bg: 'bg-emerald-500/10', text: 'text-emerald-400' },
  amber: { bg: 'bg-amber-500/10', text: 'text-amber-400' },
  violet: { bg: 'bg-violet-500/10', text: 'text-violet-400' },
};

const ContentSection: React.FC<{ icon: React.FC<React.SVGProps<SVGSVGElement>>, title: string, content: string, color: keyof typeof colorClasses }> = ({ icon: Icon, title, content, color }) => (
    <div className="mb-6">
        <div className={`flex items-center gap-3 mb-3`}>
            <div className={`p-2 rounded-lg ${colorClasses[color].bg}`}>
                <Icon className={`w-6 h-6 ${colorClasses[color].text}`} />
            </div>
            <h3 className={`text-2xl font-bold text-slate-100`}>{title}</h3>
        </div>
        <p className="text-slate-300 whitespace-pre-wrap ml-1 pl-14 border-l-2 border-slate-700">{content}</p>
    </div>
);


export const PlanDisplay: React.FC<PlanDisplayProps> = ({ planData, formData, currentDay, setCurrentDay, onReset }) => {
  const [isAnimating, setIsAnimating] = useState(false);
  const [mockData, setMockData] = useState<MockInterview | null>(null);
  const [isMockLoading, setIsMockLoading] = useState(false);
  const [mockError, setMockError] = useState<string | null>(null);
  
  // State for MCQs
  const [selectedAnswers, setSelectedAnswers] = useState<{ [key: number]: string }>({});
  const [revealedAnswers, setRevealedAnswers] = useState<number[]>([]);
  const [score, setScore] = useState(0);

  const dayData = planData.plan[currentDay];
  const totalDays = planData.plan.length;
  const isFinalReviewPage = currentDay === totalDays;

  const fetchMockData = useCallback(async () => {
    setIsMockLoading(true);
    setMockError(null);
    setMockData(null);
    // Reset MCQ state
    setSelectedAnswers({});
    setRevealedAnswers([]);
    setScore(0);
    try {
      const data = await generateMockInterview(formData.jobRole, formData.companyType);
      setMockData(data);
    } catch (err) {
      setMockError(err instanceof Error ? err.message : 'Could not load mock interview.');
    } finally {
      setIsMockLoading(false);
    }
  }, [formData.jobRole, formData.companyType]);

  useEffect(() => {
    setIsAnimating(true);
    const timer = setTimeout(() => setIsAnimating(false), 300);
    return () => clearTimeout(timer);
  }, [currentDay]);

  useEffect(() => {
    if (isFinalReviewPage && !mockData && !isMockLoading && !mockError) {
      fetchMockData();
    }
  }, [isFinalReviewPage, mockData, fetchMockData, isMockLoading, mockError]);

  const handleNavigation = (nextDay: number) => {
    if (nextDay >= 0 && nextDay <= totalDays) {
      setCurrentDay(nextDay);
    }
  };

  const handleSelectAnswer = (mcqIndex: number, option: string) => {
    if (revealedAnswers.includes(mcqIndex)) return; // Don't allow changing answer after revealing
    setSelectedAnswers(prev => ({ ...prev, [mcqIndex]: option }));
  };

  const handleCheckAnswer = (mcqIndex: number) => {
    if (!selectedAnswers[mcqIndex]) return;
    setRevealedAnswers(prev => [...prev, mcqIndex]);
    if (mockData?.mcqs && selectedAnswers[mcqIndex] === mockData.mcqs[mcqIndex]?.correctAnswer) {
      setScore(prev => prev + 1);
    }
  };
  
  const renderDayView = () => {
    if (!dayData) return null;
    return (
      <>
        <div className={`transition-opacity duration-300 ${isAnimating ? 'opacity-0' : 'opacity-100'}`}>
          <header className='mb-6'>
              <h2 className="text-3xl sm:text-4xl font-bold text-white mb-2">{dayData.title}</h2>
              <p className="text-slate-400">{planData.summary}</p>
              <ProgressBar current={currentDay} total={totalDays} />
          </header>
          
          <div className="grid grid-cols-1 lg:grid-cols-5 gap-8">
            <div className="lg:col-span-3">
              <ContentSection icon={TargetIcon} title="Topics to Cover" content={dayData.topics} color="sky" />
              <ContentSection icon={ActivityIcon} title="Activities & Resources" content={dayData.activities} color="emerald" />
              <ContentSection icon={UsersIcon} title="Soft Skills & HR Prep" content={dayData.softSkills} color="amber" />
              <ContentSection icon={LightbulbIcon} title="Notes & Tips" content={dayData.notes} color="violet" />
            </div>
             <div className="lg:col-span-2">
                <img 
                  src={DAY_IMAGES[currentDay % DAY_IMAGES.length]} 
                  alt={`Visual theme for ${dayData.title}`}
                  className="w-full h-full object-cover rounded-lg border border-slate-700 min-h-[300px]"
                />
             </div>
          </div>
        </div>
        <div className="flex justify-between items-center mt-8 pt-6 border-t border-slate-700">
          <button
            onClick={() => handleNavigation(currentDay - 1)}
            disabled={currentDay === 0}
            className="inline-flex items-center gap-2 px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-slate-600 hover:bg-slate-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-slate-500 disabled:bg-slate-700 disabled:text-slate-500 disabled:cursor-not-allowed transition-colors"
          >
            <ArrowLeftIcon className="w-4 h-4" />
            Previous
          </button>
          <button
            onClick={() => handleNavigation(currentDay + 1)}
            className="inline-flex items-center gap-2 px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition-colors"
          >
            {currentDay === totalDays - 1 ? 'Final Review' : 'Next'}
            <ArrowRightIcon className="w-4 h-4" />
          </button>
        </div>
      </>
    );
  };

  const renderMockInterviewView = () => {
    return (
      <>
        <div className={`transition-opacity duration-300 ${isAnimating ? 'opacity-0' : 'opacity-100'}`}>
          <div className="mb-4 text-center">
            <h2 className="text-3xl font-bold text-indigo-400 mb-1">🎉 Final Review & Mock Test</h2>
            <p className="text-slate-300">You’ve completed your prep journey! Take this mock test to assess your readiness.</p>
          </div>
          
          <img 
            src={DAY_IMAGES[DAY_IMAGES.length - 1]} 
            alt="Final review session"
            className="w-full h-48 object-cover rounded-lg my-6 border border-slate-700"
          />

          {isMockLoading && <LoadingSpinner />}
          {mockError && <ErrorMessage message={mockError} />}

          {mockData && (
            <div className="space-y-8">
              {mockData.technicalQuestions && mockData.technicalQuestions.length > 0 && (
                <div>
                  <h3 className="text-xl font-semibold text-slate-100 mb-2 flex items-center gap-2"><ClipboardCheckIcon className="w-6 h-6 text-indigo-400" />Mock Technical Questions</h3>
                  <ul className="list-disc list-inside space-y-2 pl-2 text-slate-300">
                    {mockData.technicalQuestions.map((q, i) => (q && q.question ? <li key={i}>{q.question}</li> : null))}
                  </ul>
                </div>
              )}

              {mockData.behavioralQuestions && mockData.behavioralQuestions.length > 0 && (
                <div>
                  <h3 className="text-xl font-semibold text-slate-100 mb-2 flex items-center gap-2"><UsersIcon className="w-6 h-6 text-indigo-400" />HR/Behavioral Questions</h3>
                  <ul className="list-disc list-inside space-y-2 pl-2 text-slate-300">
                    {mockData.behavioralQuestions.map((q, i) => (q && q.question ? <li key={i}>{q.question}</li>: null))}
                  </ul>
                </div>
              )}
              
              {mockData.mcqs && mockData.mcqs.length > 0 && (
                <div>
                  <div className="flex justify-between items-center mb-2">
                      <h3 className="text-xl font-semibold text-slate-100 flex items-center gap-2"><QuestionMarkCircleIcon className="w-6 h-6 text-indigo-400" />Multiple Choice Practice</h3>
                      {revealedAnswers.length > 0 && (
                          <p className="font-semibold text-slate-300 bg-slate-700/50 px-3 py-1 rounded-md">Score: {score} / {mockData.mcqs.length}</p>
                      )}
                  </div>
                  <div className="space-y-6">
                      {mockData.mcqs.map((mcq, index) => {
                          if (!mcq || !mcq.options || mcq.options.length < 2) return null;
                          
                          const isRevealed = revealedAnswers.includes(index);
                          const userAnswer = selectedAnswers[index];
                          const isCorrect = userAnswer === mcq.correctAnswer;
                          
                          return (
                              <div key={index} className="bg-slate-800/70 p-4 rounded-lg border border-slate-700">
                                  <p className="font-semibold text-slate-200 mb-3">{index + 1}. {mcq.question}</p>
                                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                                      {mcq.options.map((option, optIndex) => {
                                          let buttonClass = "w-full text-left p-2 rounded-md transition-colors border-2 border-slate-600 hover:bg-slate-700";
                                          if (isRevealed) {
                                              if (option === mcq.correctAnswer) {
                                                  buttonClass += " bg-green-500/20 border-green-500 text-white";
                                              } else if (option === userAnswer) {
                                                  buttonClass += " bg-red-500/20 border-red-500 text-white";
                                              } else {
                                                  buttonClass += " opacity-60";
                                              }
                                          } else if (option === userAnswer) {
                                              buttonClass += " bg-indigo-600/50 border-indigo-500";
                                          }
                                          
                                          return (
                                              <button key={optIndex} onClick={() => handleSelectAnswer(index, option)} disabled={isRevealed} className={buttonClass}>
                                                  <span className="flex items-center gap-3">
                                                      {isRevealed && option === mcq.correctAnswer && <CheckCircleIcon className="w-5 h-5 text-green-400 flex-shrink-0" />}
                                                      {isRevealed && option === userAnswer && !isCorrect && <XCircleIcon className="w-5 h-5 text-red-400 flex-shrink-0" />}
                                                      {option}
                                                  </span>
                                              </button>
                                          );
                                      })}
                                  </div>
                                  {!isRevealed && (
                                      <div className="text-right mt-3">
                                          <button onClick={() => handleCheckAnswer(index)} disabled={!userAnswer} className="text-sm font-semibold text-indigo-400 hover:text-indigo-300 disabled:text-slate-500 disabled:cursor-not-allowed">
                                              Check Answer
                                          </button>
                                      </div>
                                  )}
                              </div>
                          );
                      })}
                  </div>
                </div>
              )}

              {mockData.resources && mockData.resources.length > 0 && (
                <div>
                  <h3 className="text-xl font-semibold text-slate-100 mb-2 flex items-center gap-2"><LinkIcon className="w-6 h-6 text-indigo-400" />Suggested Practice Resources</h3>
                  <div className="space-y-3">
                    {mockData.resources.map((r, i) => (
                      r && r.url ? (
                        <a href={r.url} target="_blank" rel="noopener noreferrer" key={i} className="block bg-slate-800/70 p-3 rounded-lg border border-slate-700 hover:border-indigo-500 transition-colors">
                          <p className="font-semibold text-indigo-400">{r.name}</p>
                          <p className="text-sm text-slate-400">{r.description}</p>
                        </a>
                      ) : null
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
        <div className="flex justify-between items-center mt-6 pt-4 border-t border-slate-700">
          <button
            onClick={() => handleNavigation(currentDay - 1)}
            className="inline-flex items-center gap-2 px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-slate-600 hover:bg-slate-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-slate-500 transition-colors"
          >
            <ArrowLeftIcon className="w-4 h-4" />
            Back to Day {totalDays}
          </button>
          <button
            onClick={fetchMockData}
            disabled={isMockLoading}
            className="inline-flex items-center gap-2 px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:bg-indigo-400 disabled:cursor-not-allowed transition-colors"
          >
            <RefreshIcon className={`w-4 h-4 ${isMockLoading ? 'animate-spin' : ''}`} />
            Try New Questions
          </button>
        </div>
      </>
    );
  };

  return (
    <div className="animate-fade-in w-full">
      {isFinalReviewPage ? renderMockInterviewView() : renderDayView()}
    </div>
  );
};