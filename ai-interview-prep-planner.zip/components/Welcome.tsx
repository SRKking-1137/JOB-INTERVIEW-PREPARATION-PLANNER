import React from 'react';
import { RocketIcon } from './IconComponents';

export const Welcome: React.FC = () => {
    return (
        <div className="text-center flex flex-col items-center justify-center h-full text-slate-400">
            <RocketIcon className="w-16 h-16 text-indigo-500 mb-4"/>
            <h2 className="text-2xl font-semibold text-slate-200">Ready to Ace Your Interview?</h2>
            <p className="mt-2 max-w-md">
                Fill in your details on the left, and our AI mentor will craft a personalized preparation plan just for you.
            </p>
            <p className="mt-4 text-sm text-slate-500">Let's get you ready for your dream job!</p>
        </div>
    );
};