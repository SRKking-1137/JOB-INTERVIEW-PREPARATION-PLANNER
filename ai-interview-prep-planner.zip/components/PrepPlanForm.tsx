import React, { useState } from 'react';
import type { FormData } from '../types';
import { JOB_ROLES, EXPERIENCE_LEVELS, TIME_OPTIONS, COMPANY_TYPES } from '../constants';

interface PrepPlanFormProps {
  onGenerate: (formData: FormData) => void;
  isLoading: boolean;
}

export const PrepPlanForm: React.FC<PrepPlanFormProps> = ({ onGenerate, isLoading }) => {
  const [formData, setFormData] = useState<FormData>({
    jobRole: JOB_ROLES[0],
    experienceLevel: EXPERIENCE_LEVELS[0],
    timePerDay: TIME_OPTIONS[1],
    focusSkills: '',
    interviewDays: '7',
    companyType: COMPANY_TYPES[0],
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onGenerate(formData);
  };

  return (
    <div className="bg-slate-800/50 p-6 rounded-xl border border-slate-700/50 sticky top-8">
      <h2 className="text-xl font-bold text-white mb-4">Create Your Plan</h2>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label htmlFor="jobRole" className="block text-sm font-medium text-slate-300">Job Role</label>
          <select
            id="jobRole"
            name="jobRole"
            value={formData.jobRole}
            onChange={handleChange}
            className="mt-1 block w-full bg-slate-700 border-slate-600 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm text-white"
          >
            {JOB_ROLES.map(role => <option key={role}>{role}</option>)}
          </select>
        </div>

        <div>
          <label htmlFor="experienceLevel" className="block text-sm font-medium text-slate-300">Experience Level</label>
          <select
            id="experienceLevel"
            name="experienceLevel"
            value={formData.experienceLevel}
            onChange={handleChange}
            className="mt-1 block w-full bg-slate-700 border-slate-600 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm text-white"
          >
            {EXPERIENCE_LEVELS.map(level => <option key={level}>{level}</option>)}
          </select>
        </div>

        <div>
          <label htmlFor="interviewDays" className="block text-sm font-medium text-slate-300">Days Until Interview</label>
          <input
            type="number"
            id="interviewDays"
            name="interviewDays"
            value={formData.interviewDays}
            onChange={handleChange}
            min="1"
            max="30"
            className="mt-1 block w-full bg-slate-700 border-slate-600 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm text-white"
            required
          />
        </div>

        <div>
          <label htmlFor="companyType" className="block text-sm font-medium text-slate-300">Company Type</label>
          <select
            id="companyType"
            name="companyType"
            value={formData.companyType}
            onChange={handleChange}
            className="mt-1 block w-full bg-slate-700 border-slate-600 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm text-white"
          >
            {COMPANY_TYPES.map(type => <option key={type}>{type}</option>)}
          </select>
        </div>

        <div>
           <label htmlFor="timePerDay" className="block text-sm font-medium text-slate-300">Time Available Per Day</label>
           <select
            id="timePerDay"
            name="timePerDay"
            value={formData.timePerDay}
            onChange={handleChange}
            className="mt-1 block w-full bg-slate-700 border-slate-600 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm text-white"
          >
            {TIME_OPTIONS.map(time => <option key={time}>{time}</option>)}
          </select>
        </div>

        <div>
          <label htmlFor="focusSkills" className="block text-sm font-medium text-slate-300">
            Skills to Improve <span className="text-slate-400">(Optional)</span>
          </label>
          <textarea
            id="focusSkills"
            name="focusSkills"
            value={formData.focusSkills}
            onChange={handleChange}
            rows={3}
            placeholder="e.g., JavaScript Promises, Python Pandas, System Design basics"
            className="mt-1 block w-full bg-slate-700 border-slate-600 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm text-white"
          />
        </div>

        <button
          type="submit"
          disabled={isLoading}
          className="w-full inline-flex justify-center items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:bg-indigo-400 disabled:cursor-not-allowed transition-colors"
        >
          {isLoading ? 'Generating Plan...' : 'Generate My Plan'}
        </button>
      </form>
    </div>
  );
};