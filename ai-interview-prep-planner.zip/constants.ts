export const JOB_ROLES = [
  "Frontend Web Developer",
  "Backend Web Developer",
  "Full-Stack Web Developer",
  "Data Scientist",
  "Data Analyst",
  "Product Manager",
  "UX/UI Designer",
  "DevOps Engineer",
  "Software Development Engineer in Test (SDET)",
  "Mobile App Developer (iOS/Android)",
];

export const EXPERIENCE_LEVELS = [
  "Fresher (0 years)",
  "Early Career (0-2 years)",
];

export const TIME_OPTIONS = [
    "1-2 hours",
    "2-3 hours",
    "3-4 hours",
    "4+ hours",
];

export const COMPANY_TYPES = [
  "Startup",
  "MNC (Multinational Corporation)",
  "Product-Based Company",
  "Service-Based Company",
  "FAANG/MAANG",
  "Not Sure / General",
];

// Images sourced from Unsplash, providing relevant and engaging visuals for each day of the prep plan.
export const DAY_IMAGES = [
  'https://images.unsplash.com/photo-1542831371-29b0f74f9713?ixlib=rb-4.0.3&q=85&fm=jpg&crop=entropy&cs=srgb&w=1200', // Code on screen
  'https://images.unsplash.com/photo-1556742502-ec7c0e9f34b1?ixlib=rb-4.0.3&q=85&fm=jpg&crop=entropy&cs=srgb&w=1200', // People collaborating
  'https://images.unsplash.com/photo-1516321497487-e288fb19713f?ixlib=rb-4.0.3&q=85&fm=jpg&crop=entropy&cs=srgb&w=1200', // Whiteboard with ideas
  'https://images.unsplash.com/photo-1521737711867-e3b97375f902?ixlib=rb-4.0.3&q=85&fm=jpg&crop=entropy&cs=srgb&w=1200', // Team discussion
  'https://images.unsplash.com/photo-1587620962725-abab7fe55159?ixlib=rb-4.0.3&q=85&fm=jpg&crop=entropy&cs=srgb&w=1200', // Focused coding
  'https://images.unsplash.com/photo-1450101499163-c8848c66ca85?ixlib=rb-4.0.3&q=85&fm=jpg&crop=entropy&cs=srgb&w=1200', // Professional interview (FIXED)
  'https://images.unsplash.com/photo-1554415707-6e8cfc93fe23?ixlib=rb-4.0.3&q=85&fm=jpg&crop=entropy&cs=srgb&w=1200', // Reviewing notes
  'https://images.unsplash.com/photo-1531482615713-2c657695c282?ixlib=rb-4.0.3&q=85&fm=jpg&crop=entropy&cs=srgb&w=1200', // Presentation
  'https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?ixlib=rb-4.0.3&q=85&fm=jpg&crop=entropy&cs=srgb&w=1200', // Analytics on screen
  'https://images.unsplash.com/photo-1600880292210-f76154563d4a?ixlib=rb-4.0.3&q=85&fm=jpg&crop=entropy&cs=srgb&w=1200', // Final handshake
  'https://images.unsplash.com/photo-1519389950473-47ba0277781c?ixlib=rb-4.0.3&q=85&fm=jpg&crop=entropy&cs=srgb&w=1200', // Mock interview/team working on a problem
];